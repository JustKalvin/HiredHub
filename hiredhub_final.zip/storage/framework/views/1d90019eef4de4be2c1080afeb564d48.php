<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: white;
        }

        .card {
            background-color: #DAE1E9;
            border: none;
        }

        .card-title a {
            color: #172B4D;
            text-decoration: none;
        }

        .card-title a:hover {
            text-decoration: underline;
        }

        .section-title {
            color: #172B4D;
            font-weight: bold;
        }
    </style>
</head>

<body class="d-flex flex-column min-vh-100">
    <?php if (isset($component)) { $__componentOriginal662fac80dd7ea9f5f1f2fae88b808dd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal662fac80dd7ea9f5f1f2fae88b808dd2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chatbot','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chatbot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal662fac80dd7ea9f5f1f2fae88b808dd2)): ?>
<?php $attributes = $__attributesOriginal662fac80dd7ea9f5f1f2fae88b808dd2; ?>
<?php unset($__attributesOriginal662fac80dd7ea9f5f1f2fae88b808dd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal662fac80dd7ea9f5f1f2fae88b808dd2)): ?>
<?php $component = $__componentOriginal662fac80dd7ea9f5f1f2fae88b808dd2; ?>
<?php unset($__componentOriginal662fac80dd7ea9f5f1f2fae88b808dd2); ?>
<?php endif; ?>
    <div style="background-color: #172B4D">
        <?php echo $__env->make('components.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <div class="container py-5">

        <h1 class="mb-4 fw-bold section-title">Find Certificate</h1>

        <form action="<?php echo e(route('certificate.find')); ?>" method="POST" class="mb-4">
            <?php echo csrf_field(); ?>
            <div class="d-flex gap-2">
                <input name="keyword" type="text" class="form-control" placeholder="Search certificate">
                <button class="btn btn-dark fw-bold" type="submit">Search</button>
            </div>
        </form>

        <?php if(!empty($results)): ?>
            <h2 class="section-title mt-4 mb-3">Results for <?php echo e($keyword); ?></h2>

            <div class="row g-3">
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 shadow-lg border-0 rounded-4 p-3" style="background-color: #ffffff">

                            <div class="d-flex align-items-start gap-3">
                                <div class="rounded-circle d-flex justify-content-center align-items-center"
                                    style="width: 48px; height: 48px; background-color: #172B4D; color: white; font-weight: bold;">
                                    <?php echo e(isset($item['name']) ? strtoupper(substr($item['name'], 0, 1)) : '?'); ?>

                                </div>

                                <div class="flex-grow-1">
                                    <h5 class="card-title mb-1" style="font-size: 1.1rem;">
                                        <a href="<?php echo e($item['url'] ?? '#'); ?>" target="_blank"
                                            style="color: #172B4D; text-decoration: none;">
                                            <?php echo e($item['name'] ?? 'Unknown'); ?>

                                        </a>
                                    </h5>

                                    <a href="<?php echo e($item['url']); ?>" target="_blank" class="btn fw-bold w-100"
                                        style="background-color: #172b4d; color: white; border-radius: 10px;">
                                        Open Certificate
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if(empty($results)): ?>
            <p class="fw-bold section-title">No certificate found.</p>
        <?php endif; ?>

    </div>
    <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\kalvi\Herd\HireHub\resources\views/certificate.blade.php ENDPATH**/ ?>