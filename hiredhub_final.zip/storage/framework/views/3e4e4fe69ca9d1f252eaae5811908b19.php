<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Browse Jobs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <style>
        /* CSS Sederhana untuk mencocokkan tema gelap dari template Anda */
        body {
            background-color: white;
            /* bg-dark */
            /* color: #f8f9fa; <-- DIHAPUS, konflik dengan bg white */
            /* text-white */
        }

        .card {
            background-color: #343a40;
            /* bg-secondary */
            border: none;
        }

        .card-title a {
            color: #172B4D !important;
            /* <-- DIUBAH ke warna baru */
            /* text-white */
            text-decoration: none;
        }

        .card-title a:hover {
            text-decoration: underline;
        }

        .text-white-decoration-none {
            color: #f8f9fa !important;
            text-decoration: none;
        }

        .text-white-decoration-none:hover {
            text-decoration: underline;
        }

        .footer {
            width: 100%;
            text-align: center;
            color: white;
            /* padding: 1rem 0; */
            margin-top: auto;
        }
    </style>
</head>

<body class="d-flex flex-column min-vh-100">
    <?php if (isset($component)) { $__componentOriginal662fac80dd7ea9f5f1f2fae88b808dd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal662fac80dd7ea9f5f1f2fae88b808dd2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chatbot','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chatbot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal662fac80dd7ea9f5f1f2fae88b808dd2)): ?>
<?php $attributes = $__attributesOriginal662fac80dd7ea9f5f1f2fae88b808dd2; ?>
<?php unset($__attributesOriginal662fac80dd7ea9f5f1f2fae88b808dd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal662fac80dd7ea9f5f1f2fae88b808dd2)): ?>
<?php $component = $__componentOriginal662fac80dd7ea9f5f1f2fae88b808dd2; ?>
<?php unset($__componentOriginal662fac80dd7ea9f5f1f2fae88b808dd2); ?>
<?php endif; ?>
    
    <div style="background-color: #172B4D">
        <?php echo $__env->make('components.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>


    <div class="container py-5">
        
        <h1 class="mb-4 fw-bold" style="color: #172B4D">Browse Jobs</h1>
        <h2><?php echo e($keywords); ?> : <?php echo e($geoId); ?></h2>
        <form action="<?php echo e(route('remind')); ?>", method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" name="keywords" value="<?php echo e($keywords); ?>" hidden>
            <input type="text" name = "geoId" value="<?php echo e($geoId); ?>" hidden>
            <button class="fw-bold btn" style="background-color: #172b4d; color: white" type="submit">
                Remind Me
            </button>
        </form>
        
        <?php if(!empty($jobs) && (is_array($jobs) || $jobs instanceof \Illuminate\Support\Collection)): ?>

            
            <?php $__currentLoopData = collect($jobs)->groupBy('from'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $from => $jobList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <h2 class="text-capitalize mt-4 mb-3" style="color: #172B4D"><?php echo e($from); ?></h2>

                
                <div class="row g-3">

                    
                    <?php $__currentLoopData = $jobList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                            
                            <div class="card h-100" style="background-color: #DAE1E9">

                                
                                <div class="card-body d-flex flex-column">
                                    <h5 class="card-title">
                                        <?php if(isset($job['jobUrl'])): ?>
                                            
                                            <a href="<?php echo e($job['jobUrl']); ?>" target="_blank">
                                                <?php echo e($job['jobTitle'] ?? '-'); ?>

                                            </a>
                                        <?php else: ?>
                                            <?php echo e($job['jobTitle'] ?? '-'); ?>

                                        <?php endif; ?>
                                    </h5>

                                    <p class="mb-1">
                                        
                                        <strong style="color: #172B4D">Company:</strong>
                                        <?php if(isset($job['companyUrl']) && $job['companyUrl']): ?>
                                            
                                            <a style="color: #172B4D; text-decoration: none;"
                                                href="<?php echo e($job['companyUrl']); ?>" target="_blank">
                                                <?php echo e($job['companyName'] ?? '-'); ?>

                                            </a>
                                        <?php else: ?>
                                            <?php echo e($job['companyName'] ?? '-'); ?>

                                        <?php endif; ?>
                                    </p>

                                    <?php if(!empty($job['location'])): ?>
                                        
                                        <p class="mb-1 text-dark"><strong>Location:</strong> <?php echo e($job['location']); ?></p>
                                    <?php endif; ?>

                                    <?php if(!empty($job['postedTime'])): ?>
                                        
                                        <p class="mb-0 mt-auto pt-2 text-dark"><small>Posted:
                                                <?php echo e($job['postedTime']); ?></small></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            
            <p class="fw-bold" style="color: #172B4D">No jobs found.</p>
        <?php endif; ?>
    </div>

    
    <footer class="footer">
        <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\kalvi\Herd\HireHub\resources\views/browsejobs.blade.php ENDPATH**/ ?>